<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card rounded-0">
                <div class="card-header">
                    <h5 class="card-title">
                        <?php echo e($pageTitle); ?> (<?php echo e($submissions->count()); ?>)
                        
                        <a href="<?php echo e(route('formbuilder::forms.index')); ?>" class="btn btn-primary float-md-right btn-sm">
                            <i class="fa fa-arrow-left"></i> Back To Forms
                        </a>
                    </h5>
                </div>

                <?php if($submissions->count()): ?>
                    <div class="table-responsive">
                        <table class="table table-bordered d-table table-striped pb-0 mb-0">
                            <thead>
                                <tr>
                                    <th class="five">#</th>
                                    <th class="fifteen">User Name</th>
                                    <?php $__currentLoopData = $form_headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <th><?php echo e($header['label'] ?? title_case($header['name'])); ?></th>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <th class="fifteen">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $submissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($submission->user->name ?? 'n/a'); ?></td>
                                        <?php $__currentLoopData = $form_headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <td>
                                                <?php echo e($submission->renderEntryContent(
                                                        $header['name'], $header['type'], true
                                                    )); ?>

                                            </td>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <td>
                                            <a href="<?php echo e(route('formbuilder::forms.submissions.show', [$form, $submission->id])); ?>" class="btn btn-primary btn-sm" title="View submission">
                                                <i class="fa fa-eye"></i> View
                                            </a> 

                                            <form action="<?php echo e(route('formbuilder::forms.submissions.destroy', [$form, $submission])); ?>" method="POST" id="deleteSubmissionForm_<?php echo e($submission->id); ?>" class="d-inline-block">
                                                <?php echo csrf_field(); ?> 
                                                <?php echo method_field('DELETE'); ?>

                                                <button type="submit" class="btn btn-danger btn-sm confirm-form" data-form="deleteSubmissionForm_<?php echo e($submission->id); ?>" data-message="Delete this submission?" title="Delete submission">
                                                    <i class="fa fa-trash-o"></i> 
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <?php if($submissions->hasPages()): ?>
                        <div class="card-footer mb-0 pb-0">
                            <div><?php echo e($submissions->links()); ?></div>
                        </div>
                    <?php endif; ?>
                <?php else: ?>
                    <div class="card-body">
                        <h4 class="text-danger text-center">
                            No submission to display.
                        </h4>
                    </div>  
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('formbuilder::layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel-form-builder\resources\views/vendor/formbuilder/submissions/index.blade.php ENDPATH**/ ?>