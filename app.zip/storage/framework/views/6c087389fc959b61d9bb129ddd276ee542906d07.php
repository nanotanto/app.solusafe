<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card rounded-0">
                <div class="card-header">
                    <h5 class="card-title">
                        <?php echo e($pageTitle); ?> (<?php echo e($submissions->count()); ?>)

                        <a href="<?php echo e(route('formbuilder::forms.index')); ?>" class="btn btn-primary float-md-right btn-sm" title="Back To My Forms">
                            <i class="fa fa-th-list"></i> My Forms
                        </a>
                    </h5>
                </div>

                <?php if($submissions->count()): ?>
                    <div class="table-responsive">
                        <table class="table table-bordered d-table table-striped pb-0 mb-0">
                            <thead>
                                <tr>
                                    <th class="five">#</th>
                                    <th class="">Form</th>
                                    <th class="twenty-five">Updated On</th>
                                    <th class="twenty-five">Created On</th>
                                    <th class="fifteen">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $submissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($submission->form->name); ?></td>
                                        <td><?php echo e($submission->updated_at->toDayDateTimeString()); ?></td>
                                        <td><?php echo e($submission->created_at->toDayDateTimeString()); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('formbuilder::my-submissions.show', [$submission->id])); ?>" class="btn btn-primary btn-sm" title="View submission">
                                                <i class="fa fa-eye"></i> View
                                            </a> 

                                            <?php if($submission->form->allowsEdit()): ?>
                                                <a href="<?php echo e(route('formbuilder::my-submissions.edit', [$submission->id])); ?>" class="btn btn-primary btn-sm" title="Edit submission">
                                                    <i class="fa fa-pencil"></i> 
                                                </a> 
                                            <?php endif; ?>

                                            
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <?php if($submissions->hasPages()): ?>
                        <div class="card-footer mb-0 pb-0">
                            <div><?php echo e($submissions->links()); ?></div>
                        </div>
                    <?php endif; ?>
                <?php else: ?>
                    <div class="card-body">
                        <h4 class="text-danger text-center">
                            No submission to display.
                        </h4>
                    </div>  
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('formbuilder::layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\myproject\laravel-form-builder\resources\views/vendor/formbuilder/my_submissions/index.blade.php ENDPATH**/ ?>