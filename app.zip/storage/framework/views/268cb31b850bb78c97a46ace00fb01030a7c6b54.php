<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card rounded-0">
                <div class="card-header">
                    <h5 class="card-title">
                        Form Successfully submitted

                        <?php if(auth()->guard()->check()): ?>
                            <a href="<?php echo e(route('formbuilder::my-submissions.index')); ?>" class="btn btn-primary btn-sm float-md-right">
                                <i class="fa fa-th-list"></i> Go To My Submissions
                            </a>
                        <?php endif; ?>
                    </h5>
                </div>

                <div class="card-body">
                    <h3 class="text-center text-success">
                        Your entry for <strong><?php echo e($form->name); ?></strong> was successfully submitted.
                    </h3>
                </div>

                <div class="card-footer">
                    <a href="<?php echo e(route('home')); ?>" class="btn btn-primary confirm-form">
                        <i class="fa fa-home"></i> Return Home
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('formbuilder::layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel-form-builder\resources\views/vendor/formbuilder/render/feedback.blade.php ENDPATH**/ ?>