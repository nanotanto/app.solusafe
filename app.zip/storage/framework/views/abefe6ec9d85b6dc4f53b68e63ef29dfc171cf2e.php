<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card rounded-0">
                <div class="card-header">
                    <h5 class="card-title"><?php echo e($pageTitle); ?></h5>
                </div>

                <form action="<?php echo e(route('formbuilder::form.submit', $form->identifier)); ?>" method="POST" id="submitForm" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    
                    <div class="card-body">
                        <div id="fb-render"></div>
                    </div>

                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary confirm-form" data-form="submitForm" data-message="Submit your entry for '<?php echo e($form->name); ?>'?">
                            <i class="fa fa-submit"></i> Submit Form
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush(config('formbuilder.layout_js_stack', 'scripts')); ?>
    <script type="text/javascript">
        window._form_builder_content = <?php echo json_encode($form->form_builder_json); ?>

    </script>
    <script src="<?php echo e(asset('vendor/formbuilder/js/render-form.js')); ?><?php echo e(jazmy\FormBuilder\Helper::bustCache()); ?>" defer></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('formbuilder::layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel-form-builder\resources\views/vendor/formbuilder/render/index.blade.php ENDPATH**/ ?>