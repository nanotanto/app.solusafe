<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card rounded-0">
                <div class="card-header">
                    <h5 class="card-title">
                        Forms

                        <div class="btn-toolbar float-md-right" role="toolbar">
                            <div class="btn-group" role="group" aria-label="Third group">
                                <a href="<?php echo e(route('formbuilder::forms.create')); ?>" class="btn btn-primary btn-sm">
                                    <i class="fa fa-plus-circle"></i> Create a New Form
                                </a>

                                <a href="<?php echo e(route('formbuilder::my-submissions.index')); ?>" class="btn btn-primary btn-sm">
                                    <i class="fa fa-th-list"></i> My Submissions
                                </a>
                            </div>
                        </div>
                    </h5>
                </div>

                <?php if($forms->count()): ?>
                    <div class="table-responsive">
                        <table class="table table-bordered d-table table-striped pb-0 mb-0">
                            <thead>
                                <tr>
                                    <th class="five">#</th>
                                    <th>Name</th>
                                    <th class="ten">Visibility</th>
                                    <th class="fifteen">Allows Edit?</th>
                                    <th class="ten">Submissions</th>
                                    <th class="twenty-five">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $forms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($form->name); ?></td>
                                        <td><?php echo e($form->visibility); ?></td>
                                        <td><?php echo e($form->allowsEdit() ? 'YES' : 'NO'); ?></td>
                                        <td><?php echo e($form->submissions_count); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('formbuilder::forms.submissions.index', $form)); ?>" class="btn btn-primary btn-sm" title="View submissions for form '<?php echo e($form->name); ?>'">
                                                <i class="fa fa-th-list"></i> Data
                                            </a>
                                            <a href="<?php echo e(route('formbuilder::forms.show', $form)); ?>" class="btn btn-primary btn-sm" title="Preview form '<?php echo e($form->name); ?>'">
                                                <i class="fa fa-eye"></i> 
                                            </a> 
                                            <a href="<?php echo e(route('formbuilder::forms.edit', $form)); ?>" class="btn btn-primary btn-sm" title="Edit form">
                                                <i class="fa fa-pencil"></i> 
                                            </a> 
                                            <button class="btn btn-primary btn-sm clipboard" data-clipboard-text="<?php echo e(route('formbuilder::form.render', $form->identifier)); ?>" data-message="" data-original="" title="Copy form URL to clipboard">
                                                <i class="fa fa-clipboard"></i> 
                                            </button> 

                                            <form action="<?php echo e(route('formbuilder::forms.destroy', $form)); ?>" method="POST" id="deleteFormForm_<?php echo e($form->id); ?>" class="d-inline-block">
                                                <?php echo csrf_field(); ?> 
                                                <?php echo method_field('DELETE'); ?>

                                                <button type="submit" class="btn btn-danger btn-sm confirm-form" data-form="deleteFormForm_<?php echo e($form->id); ?>" data-message="Delete form '<?php echo e($form->name); ?>'?" title="Delete form '<?php echo e($form->name); ?>'">
                                                    <i class="fa fa-trash-o"></i> 
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <?php if($forms->hasPages()): ?>
                        <div class="card-footer mb-0 pb-0">
                            <div><?php echo e($forms->links()); ?></div>
                        </div>
                    <?php endif; ?>
                <?php else: ?>
                    <div class="card-body">
                        <h4 class="text-danger text-center">
                            No form to display.
                        </h4>
                    </div>  
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('formbuilder::layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\myproject\laravel-form-builder\resources\views/vendor/formbuilder/forms/index.blade.php ENDPATH**/ ?>